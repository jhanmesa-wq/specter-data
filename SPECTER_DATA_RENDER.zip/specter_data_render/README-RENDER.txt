SPECTER DATA — VERSIÓN 2.0
==========================

CONTENIDO
---------
public/login.html       Acceso y registro por correo.
public/consultas.html   Panel adaptable a celulares, menú plegable y compra de créditos.
server.js               API, autenticación, créditos, permisos y consultas de red.
package.json            Dependencias y comandos de Render.
.env.example            Ejemplo de variables privadas.

DESPLIEGUE EN RENDER
--------------------
1. Sube el contenido de esta carpeta a tu repositorio. Si subes la carpeta completa,
   configura "Root Directory" como specter_data_render.
2. Crea un servicio Web Service con runtime Node.
3. Build Command: npm install
4. Start Command: npm start
5. Usa Node 20 o superior.
6. Añade un Persistent Disk al servicio, con Mount Path: /var/data.
   La base SQLite se guarda en /var/data/specter.sqlite. Sin disco persistente,
   Render puede borrar la base de datos al reiniciar o desplegar.
7. En Render > servicio > Environment, añade:

   NODE_ENV=production
   DATA_DIR=/var/data
   SESSION_SECRET=<una cadena aleatoria de al menos 32 caracteres>
   ADMIN_EMAIL=<tu correo administrador>
   ADMIN_INITIAL_PASSWORD=<contraseña inicial de al menos 12 caracteres>
   TELEGRAM_USERNAME=specter_os
   CODART_TOKEN=<token privado, si lo necesitas para una futura integración autorizada>
   CODART_API_BASE=https://api-codart.cgrt.org/api/v1/consultas/fd

   Render asigna PORT automáticamente; no hace falta configurarlo.

8. Despliega. La primera vez el servidor crea la cuenta ADMIN_EMAIL con la clave
   ADMIN_INITIAL_PASSWORD. Luego puedes entrar desde /login.html.
9. Registra las cuentas normales desde la pestaña Crear cuenta. Empiezan con 0 CR.
   La cuenta administradora puede entrar a "Administración de créditos" y cargar
   saldo por correo. Cada cambio queda registrado en el historial.
10. Para cambiar el destinatario de Telegram, cambia TELEGRAM_USERNAME por tu usuario
    sin el símbolo @ y vuelve a desplegar.

SEGURIDAD Y FUNCIONAMIENTO
-------------------------
- Las contraseñas se guardan con hash bcrypt; nunca se guardan en localStorage.
- La sesión se guarda en una cookie HttpOnly, Secure (en producción) y SameSite=Lax.
- El saldo no se acepta desde el navegador. El servidor comprueba y descuenta créditos.
- Solo la cuenta inicial provisionada desde ADMIN_EMAIL puede sumar créditos.
- El token CODART, si se configura, permanece en el entorno del servidor; no se entrega
  al HTML ni se guarda en el navegador. Esta versión no llama a CODART.
- Los servicios de consulta de datos personales, domicilios, teléfonos, familiares,
  antecedentes y reconocimiento facial del archivo anterior fueron deshabilitados.
  Esta versión incluye resolución DNS y geolocalización aproximada de IP pública.
- Para evitar pérdida de usuarios y saldos, conserva el Persistent Disk al desplegar.
- Las cuentas antiguas creadas solo en localStorage no se importan; cada usuario debe
  registrarse nuevamente en esta versión.

MÚSICA
-----
El panel incluye un fondo ambiental sintetizado en el navegador y sin controles de
pausa. Android/Chrome bloquea normalmente el audio audible hasta que el usuario toca
la página por primera vez; después de ese primer toque comienza la reproducción.
